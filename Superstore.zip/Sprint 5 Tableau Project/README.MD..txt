My name is Ashley Ray, and this is my Sprint Five Tableau Project. In my analysis, I focused on product returns and identified patterns across categories and regions. I discovered key factors contributing to high return rates and pinpointed areas that could benefit from operational improvements. My insights can help reduce returns, improve customer satisfaction, and boost overall business efficiency.

https://public.tableau.com/views/AshleyRay-Sprint5Project/BusinessReturnRates?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link


This is the link to my video presentation.

https://drive.google.com/file/d/1-vCxbbIFcC1DDlR7DfwKD0NwxPpTe-cM/view?usp=sharing